package com.shabdamsdk.ui.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.shabdamsdk.R;


public class StatisticsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);
    }
}