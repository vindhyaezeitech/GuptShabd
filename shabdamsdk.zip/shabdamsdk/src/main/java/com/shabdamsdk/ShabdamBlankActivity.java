package com.shabdamsdk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShabdamBlankActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shabdam_blank);
    }
}